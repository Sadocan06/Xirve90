# Zirve90 v0.2
Modern, mobil uyumlu, statik futbol uygulaması tasarım prototipi.

## GitHub Pages yükleme
Mevcut `Sadocan06/Xirve90` deposunun kök dizinindeki `index.html`, `style.css`, `app.js` dosyalarını bu klasördeki sürümlerle değiştirin. `README.md` isteğe bağlıdır. GitHub Pages `main` / `(root)` üzerinden yayınlanır.

## Önemli
Bu sürümde tüm maçlar ve saatler **örnek** verilerdir. Canlı API, kimlik doğrulama ve push bildirimleri henüz bağlı değildir. API anahtarlarını herkese açık GitHub deposuna eklemeyin.
